from flask import Flask, request, jsonify,send_from_directory,json
from flask_pymongo import PyMongo
from datetime import datetime
from flask_cors import CORS
import os
from flask_jwt_extended import create_access_token
import bcrypt
import re
import random
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


app = Flask(__name__)
CORS(app)

# MongoDB Configuration
app.config["MONGO_URI"] = "mongodb://localhost:27017/PatientRecords"
mongo = PyMongo(app)

# Access the collection
collection = mongo.db.patients
doctors = mongo.db.doctors 


@app.route('/')
def home():
    return jsonify("Server Running on 5000...")

@app.route('/register', methods=['POST'])
def register_patient():
    data = request.get_json()

    # Extract required fields
    patient_data = {
        "name": data.get("name"),
        "gender":data.get("gender"),
        "dob": data.get("dob"),
        "blood_group": data.get("blood_group"),
        "phone": data.get("phone"),
        "email": data.get("email"),
        "city": data.get("city"),
        "state": data.get("state"),
        "allergies": [],        
        "history": []          
    }

    # Insert into MongoDB
    result = collection.insert_one(patient_data)

    return jsonify({"message": "Patient registered successfully", "patient_id": str(result.inserted_id)}), 201

@app.route('/patient', methods=['POST'])
def get_patient():
    data = request.get_json()
    email = data.get('email')

    if not email:
        return jsonify({"error": "Email is required"}), 400

    patient = collection.find_one({"email": email})

    if not patient:
        return jsonify({"error": "Patient not found"}), 404

    patient["_id"] = str(patient["_id"])  # Convert ObjectId to string

    return jsonify(patient), 200

@app.route('/update-allergies', methods=['POST'])
def update_allergies():
    data = request.json
    email = data.get("email")
    allergies = data.get("allergies")

    patient = mongo.db.patients.find_one({"email": email})
    if not patient:
        return jsonify({"error": "Patient not found"}), 404

    mongo.db.patients.update_one({"email": email}, {"$set": {"allergies": allergies}})
    return jsonify({"message": "Allergies updated successfully"}), 200

UPLOAD_FOLDER = 'reports'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)




@app.route('/reports/<path:filename>')
def serve_report(filename):
    return send_from_directory('reports', filename)


# Helper function to save uploaded files
def save_file(file):
    # Secure the filename to prevent directory traversal attacks
    filename = file.filename
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    file.save(file_path)
    return file_path

@app.route('/update-history', methods=['POST'])
def update_history():
    try:
        print("✅ Request Received")

        # Extracting required fields from `multipart/form-data`
        email = request.form.get('email')
        visit = request.form.get('visit')
        date = request.form.get('date')
        timestamp = request.form.get('timestamp')
        purpose = request.form.get('purpose', None)  # Optional
        remark = request.form.get('remark', None)    # Optional
        preconditions = request.form.getlist('preconditions[]')  # Optional
        
        # Extracting optional fields and handling JSON strings
        parameters = request.form.get('parameters', None)
        symptoms = request.form.getlist('symptoms[]')
        diagnosed_diseases = request.form.getlist('diagnosed_diseases[]')
        suggested_activities = request.form.getlist('suggested_activities[]')
        suggested_medicines = request.form.get('suggested_medicines', None)
        doctor_details = request.form.get('doctor_details', None)

        # Convert JSON strings to Python objects
        parameters = eval(parameters) if parameters else None
        suggested_medicines = eval(suggested_medicines) if suggested_medicines else None
        doctor_details = eval(doctor_details) if doctor_details else None

        # Validate required fields
        if not all([email, visit, date, timestamp]):
            return jsonify({"error": "Missing required fields"}), 400

        # Check if patient exists
        patient = collection.find_one({"email": email})
        if not patient:
            return jsonify({"error": "Patient not found"}), 404

        # Fetch the existing history
        history = patient.get("history", [])
        current_visit_history = None

        # Find the current visit's history object
        for entry in history:
            if entry.get("visit") == visit:
                current_visit_history = entry
                break

        # If no history exists for this visit, create a new one
        if not current_visit_history:
            current_visit_history = {
                "visit": visit,
                "date": date,
                "timestamp": timestamp,
                "purpose": purpose,
                "parameters": parameters or {},
                "symptoms": symptoms,
                "diagnosed_diseases": diagnosed_diseases,
                "suggested_activities": suggested_activities,
                "suggested_medicines": suggested_medicines or [],
                "doctor_details": doctor_details or {},
                "reports": [],
                "remark": remark,
                "preconditions": preconditions,
            }
            history.append(current_visit_history)
        else:
            # Update only the fields that are provided in the request
            if purpose is not None:
                current_visit_history["purpose"] = purpose
            if remark is not None:
                current_visit_history["remark"] = remark
            if preconditions:
                current_visit_history["preconditions"] = preconditions
            if parameters is not None:
                current_visit_history["parameters"] = parameters
            if symptoms:
                current_visit_history["symptoms"] = symptoms
            if diagnosed_diseases:
                current_visit_history["diagnosed_diseases"] = diagnosed_diseases
            if suggested_activities:
                current_visit_history["suggested_activities"] = suggested_activities
            if suggested_medicines is not None:
                current_visit_history["suggested_medicines"] = suggested_medicines
            if doctor_details is not None:
                current_visit_history["doctor_details"] = doctor_details

        # Handle file uploads (if any)
        uploaded_files = request.files.getlist('files')  # Use 'files' instead of 'files[]'
        report_types = request.form.getlist('report_types[]')
        file_types = request.form.getlist('file_types[]')
        
        print("Uploaded files:", uploaded_files)

        if uploaded_files:
            for i, file in enumerate(uploaded_files):
                if i < len(report_types) and i < len(file_types):
                    file_path = save_file(file)
                    current_visit_history["reports"].append({
                        "type": report_types[i],
                        "file_type": file_types[i],
                        "url": file_path  # Save the file path or URL
                    })

        # Update patient's history in the database
        collection.update_one(
            {"email": email},
            {"$set": {"history": history}}
        )

        print("✅ History updated successfully")
        return jsonify({"message": "History updated successfully", "history": current_visit_history}), 200

    except Exception as e:
        print(f"❌ Error: {e}")
        return jsonify({"error": "An error occurred while updating history."}), 500




@app.route('/signup-doctor', methods=['POST'])
def signup_doctor():
    try:
        # Get data from request
        data = request.get_json()
        
        # Extract fields
        required_fields = ['name', 'education', 'specialization', 'email', 
                          'hospitalName', 'hospitalAddress', 'contact']
        
        # Validate required fields
        for field in required_fields:
            if field not in data or not data[field].strip():
                return jsonify({"error": f"{field} is required"}), 400

        # Validate email format
        if not re.match(r"[^@]+@[^@]+\.[^@]+", data['email']):
            return jsonify({"error": "Invalid email format"}), 400

        # Validate contact number
        if not data['contact'].isdigit() or len(data['contact']) != 10:
            return jsonify({"error": "Contact must be 10 digits"}), 400

        # Check if email or contact already exists
        if doctors.find_one({"$or": [{"email": data['email']}, {"contact": data['contact']}]}):
            return jsonify({"error": "Doctor with this email or contact already exists"}), 409

        # Create doctor document
        doctor = {
            "name": data['name'],
            "education": data['education'],
            "specialization": data['specialization'],
            "email": data['email'],
            "hospitalName": data['hospitalName'],
            "hospitalAddress": data['hospitalAddress'],
            "contact": data['contact'],
            "created_at": datetime.utcnow()
        }

        # Insert into database
        result = doctors.insert_one(doctor)
        
        # Return success response
        doctor['_id'] = str(result.inserted_id)
        
        return jsonify({
            "message": "Doctor registered successfully",
            "doctor": doctor
        }), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500



# Email Configuration (Replace with your email credentials)
EMAIL_HOST = "smtp.gmail.com"  # SMTP server (e.g., Gmail)
EMAIL_PORT = 587  # Port for TLS
EMAIL_USER = "shripadwattamwar19@gmail.com"  # Your email address
EMAIL_PASSWORD = "gqvk xuln wqrw otae"  # Your email password

# # Helper function to send OTP via email
def send_otp_email(email, otp):
    try:
        # Create the email
        subject = "Your OTP for Doctor Login"
        body = f"Your OTP for login is: {otp}. It is valid for 5 minutes."

        msg = MIMEMultipart()
        msg['From'] = EMAIL_USER
        msg['To'] = email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        # Connect to the SMTP server
        with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
            server.starttls()  # Enable TLS
            server.login(EMAIL_USER, EMAIL_PASSWORD)  # Login to the email server
            server.sendmail(EMAIL_USER, email, msg.as_string())  # Send the email

        print(f"OTP sent to {email}: {otp}")
        return True
    except Exception as e:
        print(f"Failed to send email: {e}")
        return False

# Endpoint to request OTP for doctor login
@app.route('/request-otp-doctor', methods=['POST'])
def request_otp_doctor():
    try:
        data = request.json
        email = data["email"]
        print(f"{email}")

        if not email:
            return jsonify({"error": "Email is required"}), 400

        # Check if doctor exists
        doctor = mongo.db.doctors.find_one({"email": email})
        print(f"{doctor}")
        # if not doctor:
        #     return jsonify({"error": "Doctor not found"}), 404

        # Generate OTP (e.g., 6-digit code)
        otp = ''.join(random.choices('0123456789', k=6))

        # Save OTP in database (with expiration time)
        doctors.update_one(
            {"email": email},
            {"$set": {"otp": otp}}
        )

        # Send OTP via email
        if not send_otp_email(email, otp):
            return jsonify({"error": "Failed to send OTP email"}), 500

        return jsonify({"message": "OTP sent successfully"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/verify-otp-doctor', methods=['POST'])
def verify_otp_doctor():
    try:
        data = request.get_json()
        email = data.get('email')
        otp = data.get('otp')

        if not email or not otp:
            return jsonify({"error": "Email and OTP are required"}), 400

        # Normalize email if needed
        email = email.strip().lower()

        # Find doctor and check OTP
        doctor = doctors.find_one({"email": email})
        if not doctor:
            return jsonify({"error": "Doctor not found"}), 404
        
        print(f"Received OTP: {otp}")
        print(f"Stored OTP: {doctor.get('otp')}")

        if doctor.get('otp') != otp:
            return jsonify({"error": "Invalid OTP"}), 401

        # Remove OTP from the database
        doctors.update_one({"email": email}, {"$unset": {"otp": "", "otp_expires_at": ""}})

        return jsonify({
            "message": "OTP verified successfully",
            "user": {
                "_id": str(doctor['_id']),
                "name": doctor['name'],
                "email": doctor['email'],
                "specialization": doctor['specialization']
            }
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500








if __name__ == '__main__':
    app.run(debug=True,port=5000)
    
# backend - server