import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import PatientSearchForm from "./components/PatientSearchForm";
import PatientProfile from "./components/PatientProfile";
import PatientRegistration from "./components/PatientRegistration";
import MainResearchInsights from "./components/MainResearchInsights"; 
import BloodAnalyzer from "./components/BloodAnalyzer";
import Docsignup from "./components/Signup";
import Login from "./components/Login";
import CoverPage from "./components/DoctorCover";
import DiabetesRAG from "./components/DiabetesRag";
import RiskAssessment from "./components/Risk";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<CoverPage />} />
        <Route path="/signup/doctor" element={<Docsignup />} />
        <Route path="/login/doctor" element={<Login/>}/>
        <Route path="/doctor/dashboard" element={<PatientSearchForm />} />
        <Route path="/patient-registration" element={<PatientRegistration />} />
        <Route path="/patient-profile" element={<PatientProfile />} />
        <Route path="/research-insights" element={<MainResearchInsights />} />
        <Route path="/diagnosis-blood-report" element={<BloodAnalyzer />} />
        <Route path="/diabetes-rag" element={<DiabetesRAG />} />
        <Route path="/risk-assesment" element={<RiskAssessment />} />
      </Routes>
    </Router>
  );
};

export default App;