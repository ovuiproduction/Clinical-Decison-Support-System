// import React, { useState } from "react";
// import axios from "axios";
// import "../static/css/AddHistoryForm.css";

// const AddHistoryForm = ({ onClose, onSubmit, patient, visitCount }) => {
//   const [purpose, setPurpose] = useState("");
//   const [preconditions,setPreConditions] = ([])
//   const [preconditionInput, setPreconditionInput] = useState("");
//   const [parameters, setParameters] = useState([]);
//   const [paramKey, setParamKey] = useState("");
//   const [paramValue, setParamValue] = useState("");
//   const [symptoms, setSymptoms] = useState([]);
//   const [symptomInput, setSymptomInput] = useState("");
//   const [remark, setRemark] = useState("");
//   const [diagnosedDiseases, setDiagnosedDiseases] = useState([]);
//   const [diseaseInput, setDiseaseInput] = useState("");
//   const [activities, setActivities] = useState([]);
//   const [activityInput, setActivityInput] = useState("");
//   const [medicines, setMedicines] = useState([]);
//   const [medicine, setMedicine] = useState({ name: "", dosage: "", duration: "" });
//   const [reports, setReports] = useState([]);
//   const [reportType, setReportType] = useState("");
//   const [fileType, setFileType] = useState("");
//   const [file, setFile] = useState(null);
//   const [doctorDetails, setDoctorDetails] = useState({
//     name: "",
//     specialization: "",
//     contact: "",
//     hospital: "",
//   });

//   // ➤ Add Parameter
//   const handleAddParameter = () => {
//     if (paramKey && paramValue) {
//       setParameters([{ [paramKey]: paramValue }, ...parameters]);
//       setParamKey("");
//       setParamValue("");
//     }
//   };

//   // ➤ Add Symptom
//   const handleAddSymptom = () => {
//     if (symptomInput) {
//       setSymptoms([symptomInput, ...symptoms]);
//       setSymptomInput("");
//     }
//   };

//   const handleAddPreconditions = () => {
//     if (preconditionInput) {
//       setSymptoms([preconditionInput, ...preconditions]);
//       setPreconditionInput("");
//     }
//   };

//   // ➤ Analyze Symptoms (Predict Diseases)
//   const handleAnalyzeSymptoms = async () => {
//     if (symptoms.length === 0) return alert("Please enter symptoms first.");
  
//     try {
//       // Send symptoms as a JSON array
//       const response = await axios.post("http://localhost:4000/predict-disease", {
//         symptoms: symptoms.join(", "), // Convert array to a comma-separated string
//       }, {
//         headers: {
//           "Content-Type": "application/json",
//         },
//       });
  
//       const predictedDisease = response.data;
//       if (predictedDisease) {
//         setDiseaseInput(predictedDisease.diagnosis);
//       }
//     } catch (error) {
//       console.error("❌ Error predicting diseases: ", error);
//       alert("Failed to analyze symptoms.");
//     }
//   };
  

//   // handle suggest activities
//   const handleSuggestActivities = async () => {
//     if (parameters.length === 0) return alert("Please provide at least one parameter.");
  
//     // Convert parameters array to "key:value" string format
//     const parameterString = parameters
//       .map((param) => {
//         const key = Object.keys(param)[0];  // Extract key
//         const value = param[key];           // Extract value
//         return `${key}:${value}`;           // Format as "key:value"
//       })
//       .join(", ");


//       let preconditionsString = preconditions.join(", ");
  
//     // Prepare request payload (use plain object instead of FormData)
//     const payload = {
//       observations: parameterString,
//       gender: patient.gender,
//       dob: patient.dob,
//       conditions:preconditionsString
//     };
  
//     try {
//       const response = await axios.post(
//         "http://localhost:4000/suggest-activities",
//         payload, // Pass the JSON object directly
//         {
//           headers: {
//             "Content-Type": "application/json", // Ensure correct content type
//           },
//         }
//       );
  
//       // Extract suggested activities and update the state
//       const suggestedActivities = response.data.activities;
//       console.log(suggestedActivities)
//       if (suggestedActivities) {
//         setActivities((prev) => [...new Set([...suggestedActivities, ...prev])]);
//       }
//     } catch (error) {
//       console.error("❌ Error suggesting activities: ", error);
//       alert("Failed to suggest activities.");
//     }
//   };
  

//   // ➤ Add Disease
//   const handleAddDisease = () => {
//     if (diseaseInput) {
//       setDiagnosedDiseases([diseaseInput, ...diagnosedDiseases]);
//       setDiseaseInput("");
//     }
//   };

//   // ➤ Add Activity
//   const handleAddActivity = () => {
//     if (activityInput) {
//       setActivities([activityInput, ...activities]);
//       setActivityInput("");
//     }
//   };

//   // ➤ Add Medicine
//   const handleAddMedicine = () => {
//     if (medicine.name && medicine.dosage && medicine.duration) {
//       setMedicines([medicine, ...medicines]);
//       setMedicine({ name: "", dosage: "", duration: "" });
//     }
//   };

//   // ➤ Add Report
//   const handleAddReport = () => {
//     if (reportType && fileType && file) {
//       setReports([{ reportType, fileType, file }, ...reports]);
//       setReportType("");
//       setFileType("");
//       setFile(null);
//     }
//   };

//   // ➤ Submit Form
//   const handleSubmit = async () => {
//     const formData = new FormData();
//     formData.append("email", patientEmail);
//     formData.append("visit", `Visit ${visitCount ? visitCount + 1 : 1}`);
//     formData.append("date", new Date().toISOString().split("T")[0]);
//     formData.append("timestamp", new Date().toLocaleTimeString());
//     formData.append("purpose", purpose);
//     formData.append("remark", remark);
//     preconditions.forEach((precondition) => formData.append("preconditions[]", precondition));
//     formData.append("parameters", JSON.stringify(Object.assign({}, ...parameters)));
//     symptoms.forEach((symptom) => formData.append("symptoms[]", symptom));
//     diagnosedDiseases.forEach((disease) => formData.append("diagnosed_diseases[]", disease));
//     activities.forEach((activity) => formData.append("suggested_activities[]", activity));
//     formData.append("suggested_medicines", JSON.stringify(medicines));
//     formData.append("doctor_details", JSON.stringify(doctorDetails));

//     reports.forEach(({ reportType, fileType, file }) => {
//       formData.append("report_types[]", reportType);
//       formData.append("file_types[]", fileType);
//       if (file) formData.append("files[]", file);
//     });

//     try {
//       const response = await axios.post("http://localhost:5000/update-history", formData, {
//         headers: { "Content-Type": "multipart/form-data" },
//       });
//       console.log("✅ History Updated: ", response.data);
//       onSubmit(response.data);
//       onClose();
//     } catch (error) {
//       console.error("❌ Error updating history", error);
//     }
//   };

//   return (
//     <div className="modal-overlay">
//       <div className="modal-content">
//         <h2>Add Patient Visit History</h2>

//         <label>Purpose of Visit:</label>
//         <textarea value={purpose} onChange={(e) => setPurpose(e.target.value)} />

//         <label>Parameters:</label>
//         {parameters.map((param, index) => (
//           <div key={index}>{Object.keys(param)[0]}: {Object.values(param)[0]}</div>
//         ))}
//         <input value={paramKey} onChange={(e) => setParamKey(e.target.value)} placeholder="Parameter Name" />
//         <input value={paramValue} onChange={(e) => setParamValue(e.target.value)} placeholder="Value" />
//         <button onClick={handleAddParameter}>Add Parameter</button>
//         <button onClick={handleSuggestActivities}>Analyze Parameters</button>

//         <label>Symptoms:</label>
//         {symptoms.map((symptom, index) => (
//           <div key={index}>{symptom}</div>
//         ))}
//         <input value={symptomInput} onChange={(e) => setSymptomInput(e.target.value)} placeholder="Symptom" />
//         <button onClick={handleAddSymptom}>Add Symptom</button>
//         <button onClick={handleAnalyzeSymptoms}>Analyze Symptoms</button>
       
        
//         <label>Diagnosed Diseases:</label>
//         {diagnosedDiseases.map((disease, index) => (
//           <div key={index}>{disease}</div>
//         ))}
//         <input value={diseaseInput} onChange={(e) => setDiseaseInput(e.target.value)} placeholder="Disease" />
//         <button onClick={handleAddDisease}>Add Disease</button>
        
//         <label>Preconditions :</label>
//         {preconditions.map((precondition, index) => (
//           <div key={index}>{precondition}</div>
//         ))}
//         <input value={preconditionInput} onChange={(e) => setPreconditionInput(e.target.value)} placeholder="Symptom" />
//         <button onClick={handleAddPreconditions}>Add Symptom</button>
        
//         <label>Suggested Activities:</label>
//         {activities.map((activity, index) => (
//           <div key={index}>{activity}</div>
//         ))}
//         <input value={activityInput} onChange={(e) => setActivityInput(e.target.value)} placeholder="Activity" />
//         <button onClick={handleAddActivity}>Add Activity</button>

//         <label>Suggested Medicines:</label>
//         {medicines.map((med, index) => (
//           <div key={index}>{med.name} - {med.dosage} - {med.duration}</div>
//         ))}
//         <input placeholder="Name" value={medicine.name} onChange={(e) => setMedicine({ ...medicine, name: e.target.value })} />
//         <input placeholder="Dosage" value={medicine.dosage} onChange={(e) => setMedicine({ ...medicine, dosage: e.target.value })} />
//         <input placeholder="Duration" value={medicine.duration} onChange={(e) => setMedicine({ ...medicine, duration: e.target.value })} />
//         <button onClick={handleAddMedicine}>Add Medicine</button>

//         <label>Upload Report:</label>
//           {reports.map((report, index) => (
//           <div key={index}>{report.reportType} - {report.fileType}</div>
//         ))}
//         <select value={reportType} onChange={(e) => setReportType(e.target.value)}>
//           <option value="">Select Report Type</option>
//           <option value="Blood Report">Blood Report</option>
//           <option value="X-Ray">X-Ray</option>
//         </select>
//         <select value={fileType} onChange={(e) => setFileType(e.target.value)}>
//           <option value="">Select File Type</option>
//           <option value="Image">Image</option>
//           <option value="Pdf">PDF</option>
//         </select>
//         <input type="file" onChange={(e) => setFile(e.target.files[0])} />
//         <button onClick={handleAddReport}>Add Report</button>

//         <button onClick={handleSubmit}>Submit</button>
//         <button onClick={onClose}>Cancel</button>
//       </div>
//     </div>
//   );
// };

// export default AddHistoryForm;


// import React, { useState } from "react";
// import axios from "axios";
// import "../static/css/AddHistoryForm.css";

// const AddHistoryForm = ({ onClose, onSubmit, patient, visitCount }) => {
//   const [activeSection, setActiveSection] = useState("purpose");
//   const [purpose, setPurpose] = useState("");
//   const [preconditions, setPreconditions] = useState([]);
//   const [preconditionInput, setPreconditionInput] = useState("");
//   const [parameters, setParameters] = useState([]);
//   const [paramKey, setParamKey] = useState("");
//   const [paramValue, setParamValue] = useState("");
//   const [symptoms, setSymptoms] = useState([]);
//   const [symptomInput, setSymptomInput] = useState("");
//   const [remark, setRemark] = useState("");
//   const [diagnosedDiseases, setDiagnosedDiseases] = useState([]);
//   const [diseaseInput, setDiseaseInput] = useState("");
//   const [activities, setActivities] = useState([]);
//   const [activityInput, setActivityInput] = useState("");
//   const [medicines, setMedicines] = useState([]);
//   const [medicine, setMedicine] = useState({ name: "", dosage: "", duration: "" });
//   const [reports, setReports] = useState([]);
//   const [reportType, setReportType] = useState("");
//   const [fileType, setFileType] = useState("");
//   const [file, setFile] = useState(null);
//   const [doctorDetails, setDoctorDetails] = useState({
//     name: "",
//     specialization: "",
//     contact: "",
//     hospital: "",
//   });

//   // ➤ Add Parameter
//   const handleAddParameter = () => {
//     if (paramKey && paramValue) {
//       setParameters([{ [paramKey]: paramValue }, ...parameters]);
//       setParamKey("");
//       setParamValue("");
//     }
//   };

//   // ➤ Add Symptom
//   const handleAddSymptom = () => {
//     if (symptomInput) {
//       setSymptoms([symptomInput, ...symptoms]);
//       setSymptomInput("");
//     }
//   };

//   const handleAddPreconditions = () => {
//     if (preconditionInput) {
//       setPreconditions([preconditionInput, ...preconditions]);
//       setPreconditionInput("");
//     }
//   };

//   // ➤ Analyze Symptoms (Predict Diseases)
//   const handleAnalyzeSymptoms = async () => {
//     if (symptoms.length === 0) return alert("Please enter symptoms first.");
  
//     try {
//       const response = await axios.post("http://localhost:4000/predict-disease", {
//         symptoms: symptoms.join(", "),
//       }, {
//         headers: {
//           "Content-Type": "application/json",
//         },
//       });
  
//       const predictedDisease = response.data;
//       if (predictedDisease) {
//         setDiseaseInput(predictedDisease.diagnosis);
//       }
//     } catch (error) {
//       console.error("❌ Error predicting diseases: ", error);
//       alert("Failed to analyze symptoms.");
//     }
//   };

//   // handle suggest activities
//   const handleSuggestActivities = async () => {
//     if (parameters.length === 0) return alert("Please provide at least one parameter.");
  
//     const parameterString = parameters
//       .map((param) => {
//         const key = Object.keys(param)[0];
//         const value = param[key];
//         return `${key}:${value}`;
//       })
//       .join(", ");

//     let preconditionsString = preconditions.join(", ");
  
//     const payload = {
//       observations: parameterString,
//       gender: patient.gender,
//       dob: patient.dob,
//       conditions: preconditionsString
//     };
  
//     try {
//       const response = await axios.post(
//         "http://localhost:4000/suggest-activities",
//         payload,
//         {
//           headers: {
//             "Content-Type": "application/json",
//           },
//         }
//       );
  
//       const suggestedActivities = response.data.activities;
//       console.log(suggestedActivities)
//       if (suggestedActivities) {
//         setActivities((prev) => [...new Set([...suggestedActivities, ...prev])]);
//       }
//     } catch (error) {
//       console.error("❌ Error suggesting activities: ", error);
//       alert("Failed to suggest activities.");
//     }
//   };

//   // ➤ Add Disease
//   const handleAddDisease = () => {
//     if (diseaseInput) {
//       setDiagnosedDiseases([diseaseInput, ...diagnosedDiseases]);
//       setDiseaseInput("");
//     }
//   };

//   // ➤ Add Activity
//   const handleAddActivity = () => {
//     if (activityInput) {
//       setActivities([activityInput, ...activities]);
//       setActivityInput("");
//     }
//   };

//   // ➤ Add Medicine
//   const handleAddMedicine = () => {
//     if (medicine.name && medicine.dosage && medicine.duration) {
//       setMedicines([medicine, ...medicines]);
//       setMedicine({ name: "", dosage: "", duration: "" });
//     }
//   };

//   // ➤ Add Report
//   const handleAddReport = () => {
//     if (reportType && fileType && file) {
//       setReports([{ reportType, fileType, file }, ...reports]);
//       setReportType("");
//       setFileType("");
//       setFile(null);
//     }
//   };

//   // ➤ Save Changes
//   const handleSaveChanges = async () => {
//     const formData = new FormData();
//     formData.append("email", patient.email);
//     formData.append("visit", `Visit ${visitCount ? visitCount + 1 : 1}`);
//     formData.append("date", new Date().toISOString().split("T")[0]);
//     formData.append("timestamp", new Date().toLocaleTimeString());
//     formData.append("purpose", purpose);
//     formData.append("remark", remark);
//     preconditions.forEach((precondition) => formData.append("preconditions[]", precondition));
//     formData.append("parameters", JSON.stringify(Object.assign({}, ...parameters)));
//     symptoms.forEach((symptom) => formData.append("symptoms[]", symptom));
//     diagnosedDiseases.forEach((disease) => formData.append("diagnosed_diseases[]", disease));
//     activities.forEach((activity) => formData.append("suggested_activities[]", activity));
//     formData.append("suggested_medicines", JSON.stringify(medicines));
//     formData.append("doctor_details", JSON.stringify(doctorDetails));

//     reports.forEach(({ reportType, fileType, file }) => {
//       formData.append("report_types[]", reportType);
//       formData.append("file_types[]", fileType);
//       if (file) formData.append("files[]", file);
//     });

//     try {
//       const response = await axios.post("http://localhost:5000/update-history", formData, {
//         headers: { "Content-Type": "multipart/form-data" },
//       });
//       console.log("✅ History Updated: ", response.data);
//       onSubmit(response.data);
//       onClose();
//     } catch (error) {
//       console.error("❌ Error updating history", error);
//     }
//   };

//   const renderSection = () => {
//     switch (activeSection) {
//       case "purpose":
//         return (
//           <div>
//             <label>Purpose of Visit:</label>
//             <textarea value={purpose} onChange={(e) => setPurpose(e.target.value)} />
//           </div>
//         );
//       case "parameters":
//         return (
//           <div>
//             <label>Parameters:</label>
//             {parameters.map((param, index) => (
//               <div key={index}>{Object.keys(param)[0]}: {Object.values(param)[0]}</div>
//             ))}
//             <input value={paramKey} onChange={(e) => setParamKey(e.target.value)} placeholder="Parameter Name" />
//             <input value={paramValue} onChange={(e) => setParamValue(e.target.value)} placeholder="Value" />
//             <button onClick={handleAddParameter}>Add Parameter</button>
//             <button onClick={handleSuggestActivities}>Analyze Parameters</button>
//           </div>
//         );
//       case "symptoms":
//         return (
//           <div>
//             <label>Symptoms:</label>
//             {symptoms.map((symptom, index) => (
//               <div key={index}>{symptom}</div>
//             ))}
//             <input value={symptomInput} onChange={(e) => setSymptomInput(e.target.value)} placeholder="Symptom" />
//             <button onClick={handleAddSymptom}>Add Symptom</button>
//             <button onClick={handleAnalyzeSymptoms}>Analyze Symptoms</button>
//           </div>
//         );
//       case "diagnosedDiseases":
//         return (
//           <div>
//             <label>Diagnosed Diseases:</label>
//             {diagnosedDiseases.map((disease, index) => (
//               <div key={index}>{disease}</div>
//             ))}
//             <input value={diseaseInput} onChange={(e) => setDiseaseInput(e.target.value)} placeholder="Disease" />
//             <button onClick={handleAddDisease}>Add Disease</button>
//           </div>
//         );
//       case "preconditions":
//         return (
//           <div>
//             <label>Preconditions:</label>
//             {preconditions.map((precondition, index) => (
//               <div key={index}>{precondition}</div>
//             ))}
//             <input value={preconditionInput} onChange={(e) => setPreconditionInput(e.target.value)} placeholder="Precondition" />
//             <button onClick={handleAddPreconditions}>Add Precondition</button>
//           </div>
//         );
//       case "activities":
//         return (
//           <div>
//             <label>Suggested Activities:</label>
//             {activities.map((activity, index) => (
//               <div key={index}>{activity}</div>
//             ))}
//             <input value={activityInput} onChange={(e) => setActivityInput(e.target.value)} placeholder="Activity" />
//             <button onClick={handleAddActivity}>Add Activity</button>
//           </div>
//         );
//       case "medicines":
//         return (
//           <div>
//             <label>Suggested Medicines:</label>
//             {medicines.map((med, index) => (
//               <div key={index}>{med.name} - {med.dosage} - {med.duration}</div>
//             ))}
//             <input placeholder="Name" value={medicine.name} onChange={(e) => setMedicine({ ...medicine, name: e.target.value })} />
//             <input placeholder="Dosage" value={medicine.dosage} onChange={(e) => setMedicine({ ...medicine, dosage: e.target.value })} />
//             <input placeholder="Duration" value={medicine.duration} onChange={(e) => setMedicine({ ...medicine, duration: e.target.value })} />
//             <button onClick={handleAddMedicine}>Add Medicine</button>
//           </div>
//         );
//       case "reports":
//         return (
//           <div>
//             <label>Upload Report:</label>
//             {reports.map((report, index) => (
//               <div key={index}>{report.reportType} - {report.fileType}</div>
//             ))}
//             <select value={reportType} onChange={(e) => setReportType(e.target.value)}>
//               <option value="">Select Report Type</option>
//               <option value="Blood Report">Blood Report</option>
//               <option value="X-Ray">X-Ray</option>
//             </select>
//             <select value={fileType} onChange={(e) => setFileType(e.target.value)}>
//               <option value="">Select File Type</option>
//               <option value="Image">Image</option>
//               <option value="Pdf">PDF</option>
//             </select>
//             <input type="file" onChange={(e) => setFile(e.target.files[0])} />
//             <button onClick={handleAddReport}>Add Report</button>
//           </div>
//         );
//       default:
//         return null;
//     }
//   };

//   return (
//     <div className="modal-overlay">
//       <div className="modal-content">
//         <h2>Add Patient Visit History</h2>
//         <div className="patient-header">
//           <h3>Patient: {patient.name}</h3>
//           <p>Email: {patient.email}</p>
//         </div>
//         <div className="layout-container">
//           <div className="sidebar">
//             <ul>
//               <li onClick={() => setActiveSection("purpose")}>Purpose</li>
//               <li onClick={() => setActiveSection("parameters")}>Parameters</li>
//               <li onClick={() => setActiveSection("symptoms")}>Symptoms</li>
//               <li onClick={() => setActiveSection("diagnosedDiseases")}>Diagnosed Diseases</li>
//               <li onClick={() => setActiveSection("preconditions")}>Preconditions</li>
//               <li onClick={() => setActiveSection("activities")}>Activities</li>
//               <li onClick={() => setActiveSection("medicines")}>Medicines</li>
//               <li onClick={() => setActiveSection("reports")}>Reports</li>
//             </ul>
//           </div>
//           <div className="main-content">
//             {renderSection()}
//             <button onClick={handleSaveChanges}>Save Changes</button>
//             <button onClick={onClose}>Cancel</button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AddHistoryForm;


import React, { useState, useEffect } from "react";
import axios from "axios";
import "../static/css/AddHistoryForm.css";

const AddHistoryForm = ({ onClose, patient, selectedHistory, visitCount }) => {
  const [activeSection, setActiveSection] = useState("purpose");
  const [purpose, setPurpose] = useState(selectedHistory?.purpose || "");
  const [preconditions, setPreconditions] = useState(
    selectedHistory?.preconditions || []
  );
  const [preconditionInput, setPreconditionInput] = useState("");
  const [parameters, setParameters] = useState(
    selectedHistory?.parameters
      ? Object.entries(selectedHistory.parameters).map(([key, value]) => ({ [key]: value }))
      : []
  );

  const [paramKey, setParamKey] = useState("");
  const [paramValue, setParamValue] = useState("");
  const [symptoms, setSymptoms] = useState(selectedHistory?.symptoms || []);
  const [symptomInput, setSymptomInput] = useState("");
  const [remark, setRemark] = useState(selectedHistory?.remark || "");
  const [diagnosedDiseases, setDiagnosedDiseases] = useState(
    selectedHistory?.diagnosed_diseases || []
  );
  const [diseaseInput, setDiseaseInput] = useState("");
  const [activities, setActivities] = useState(
    selectedHistory?.suggested_activities || []
  );
  const [activityInput, setActivityInput] = useState("");
  const [medicines, setMedicines] = useState(
    selectedHistory?.suggested_medicines || []
  );
  const [medicine, setMedicine] = useState({ name: "", dosage: "", duration: "" });
  const [reports, setReports] = useState(selectedHistory?.reports || []);
  const [reportType, setReportType] = useState("");
  const [fileType, setFileType] = useState("");
  const [file, setFile] = useState(null);
  const [doctorDetails, setDoctorDetails] = useState(
    selectedHistory?.doctor_details || {
      name: "",
      specialization: "",
      contact: "",
      hospital: "",
    }
  );
  const [notification, setNotification] = useState(null);




  // Pre-fill form fields when selectedHistory changes
  useEffect(() => {
    if (selectedHistory) {
      setPurpose(selectedHistory.purpose || "");
      setPreconditions(selectedHistory.preconditions || []);
      setParameters(
        selectedHistory.parameters
          ? Object.entries(selectedHistory.parameters).map(([key, value]) => ({ [key]: value }))
          : []
      );
      setSymptoms(selectedHistory.symptoms || []);
      setRemark(selectedHistory.remark || "");
      setDiagnosedDiseases(selectedHistory.diagnosed_diseases || []);
      setActivities(selectedHistory.suggested_activities || []);
      setMedicines(selectedHistory.suggested_medicines || []);
      setReports(selectedHistory.reports || []);
      setDoctorDetails(selectedHistory.doctor_details || {
        name: "",
        specialization: "",
        contact: "",
        hospital: "",
      });
    }
  }, [selectedHistory]);

  // ➤ Show notification
  const showNotification = (message, isSuccess = true) => {
    setNotification({ message, isSuccess });
    setTimeout(() => setNotification(null), 3000); // Hide notification after 3 seconds
  };

  // ➤ Add Parameter
  const handleAddParameter = () => {
    if (paramKey && paramValue) {
      setParameters([...parameters, { [paramKey]: paramValue }]);
      setParamKey("");
      setParamValue("");
    }
  };

  // ➤ Delete Parameter
  const handleDeleteParameter = (index) => {
    const updatedParameters = parameters.filter((_, i) => i !== index);
    setParameters(updatedParameters);
  };

  // ➤ Add Symptom
  const handleAddSymptom = () => {
    if (symptomInput) {
      setSymptoms([...symptoms, symptomInput]);
      setSymptomInput("");
    }
  };

  // ➤ Delete Symptom
  const handleDeleteSymptom = (index) => {
    const updatedSymptoms = symptoms.filter((_, i) => i !== index);
    setSymptoms(updatedSymptoms);
  };

  // ➤ Add Precondition
  const handleAddPrecondition = () => {
    if (preconditionInput) {
      setPreconditions([...preconditions, preconditionInput]);
      setPreconditionInput("");
    }
  };

  // ➤ Delete Precondition
  const handleDeletePrecondition = (index) => {
    const updatedPreconditions = preconditions.filter((_, i) => i !== index);
    setPreconditions(updatedPreconditions);
  };

  // ➤ Add Disease
  const handleAddDisease = () => {
    if (diseaseInput) {
      setDiagnosedDiseases([...diagnosedDiseases, diseaseInput]);
      setDiseaseInput("");
    }
  };

  // ➤ Delete Disease
  const handleDeleteDisease = (index) => {
    const updatedDiseases = diagnosedDiseases.filter((_, i) => i !== index);
    setDiagnosedDiseases(updatedDiseases);
  };

  // ➤ Add Activity
  const handleAddActivity = () => {
    if (activityInput) {
      setActivities([...activities, activityInput]);
      setActivityInput("");
    }
  };

  // ➤ Delete Activity
  const handleDeleteActivity = (index) => {
    const updatedActivities = activities.filter((_, i) => i !== index);
    setActivities(updatedActivities);
  };

  // ➤ Add Medicine
  const handleAddMedicine = () => {
    if (medicine.name && medicine.dosage && medicine.duration) {
      setMedicines([...medicines, medicine]);
      setMedicine({ name: "", dosage: "", duration: "" });
    }
  };

  // ➤ Delete Medicine
  const handleDeleteMedicine = (index) => {
    const updatedMedicines = medicines.filter((_, i) => i !== index);
    setMedicines(updatedMedicines);
  };

  // ➤ Add Report
  const handleAddReport = () => {
    if (reportType && fileType && file) {
      const newReport = {
        type: reportType,
        file_type: fileType,
        file: file, // Store the file object directly
      };
      setReports([...reports, newReport]);
      setReportType("");
      setFileType("");
      setFile(null);
    }
  };

  // ➤ Delete Report
  const handleDeleteReport = (index) => {
    const updatedReports = reports.filter((_, i) => i !== index);
    setReports(updatedReports);
    console.log(updatedReports);
  };

  const handleSaveChanges = async () => {
    const formData = new FormData();
    formData.append("email", patient.email);
    formData.append("visit", selectedHistory ? selectedHistory.visit : `Visit ${visitCount ? visitCount + 1 : 1}`);
    formData.append("date", new Date().toISOString().split("T")[0]);
    formData.append("timestamp", new Date().toLocaleTimeString());
    formData.append("remark", remark);
  
    // Append data based on the active section
    switch (activeSection) {
      case "purpose":
        formData.append("purpose", purpose);
        break;
      case "parameters":
        formData.append("parameters", JSON.stringify(Object.assign({}, ...parameters)));
        break;
      case "symptoms":
        symptoms.forEach((symptom) => formData.append("symptoms[]", symptom));
        break;
      case "diagnosedDiseases":
        diagnosedDiseases.forEach((disease) => formData.append("diagnosed_diseases[]", disease));
        break;
      case "preconditions":
        preconditions.forEach((precondition) => formData.append("preconditions[]", precondition));
        break;
      case "activities":
        activities.forEach((activity) => formData.append("suggested_activities[]", activity));
        break;
      case "medicines":
        formData.append("suggested_medicines", JSON.stringify(medicines));
        break;
      case "reports":
        reports.forEach((report) => {
          formData.append("report_types[]", report.type);
          formData.append("file_types[]", report.file_type);
          formData.append("files", report.file); // Append each file with the same key
        });
        break;
      default:
        break;
    }
  
    try {
      const response = await axios.post("http://localhost:5000/update-history", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      console.log("✅ History Updated: ", response.data);
      showNotification("Changes saved successfully!", true);
    } catch (error) {
      console.error("❌ Error updating history", error);
      showNotification("Failed to save changes. Please try again.", false);
    }
  };

    // ➤ Analyze Symptoms (Predict Diseases)
  const handleAnalyzeSymptoms = async () => {
    if (symptoms.length === 0) return alert("Please enter symptoms first.");
  
    try {
      // Send symptoms as a JSON array
      const response = await axios.post("http://localhost:4000/predict-disease", {
        symptoms: symptoms.join(", "), // Convert array to a comma-separated string
      }, {
        headers: {
          "Content-Type": "application/json",
        },
      });
  
      const predictedDisease = response.data;
      console.log(predictedDisease);
      console.log(predictedDisease.disease);
      
      if (predictedDisease) {
        setDiseaseInput(predictedDisease.disease);
      }
    } catch (error) {
      console.error("❌ Error predicting diseases: ", error);
      alert("Failed to analyze symptoms.");
    }
  };
  

  // handle suggest activities
  const handleSuggestActivities = async () => {
    if (parameters.length === 0) return alert("Please provide at least one parameter.");
  
    // Convert parameters array to "key:value" string format
    const parameterString = parameters
      .map((param) => {
        const key = Object.keys(param)[0];  // Extract key
        const value = param[key];           // Extract value
        return `${key}:${value}`;           // Format as "key:value"
      })
      .join(", ");


      let preconditionsString = preconditions.join(", ");
  
    // Prepare request payload (use plain object instead of FormData)
    const payload = {
      observations: parameterString,
      gender: patient.gender,
      dob: patient.dob,
      conditions:preconditionsString
    };
  
    try {
      const response = await axios.post(
        "http://localhost:4000/suggest-activities",
        payload, // Pass the JSON object directly
        {
          headers: {
            "Content-Type": "application/json", // Ensure correct content type
          },
        }
      );
  
      // Extract suggested activities and update the state
      const suggestedActivities = response.data.activities;
      console.log(suggestedActivities)
      if (suggestedActivities) {
        setActivities((prev) => [...new Set([...suggestedActivities, ...prev])]);
      }
    } catch (error) {
      console.error("❌ Error suggesting activities: ", error);
      alert("Failed to suggest activities.");
    }
  };

  // ➤ Render the active section
  const renderSection = () => {
    switch (activeSection) {
      case "purpose":
        return (
          <div>
            <label>Purpose of Visit:</label>
            <textarea value={purpose} onChange={(e) => setPurpose(e.target.value)} />
          </div>
        );
      case "parameters":
        return (
          <div>
            <label>Parameters:</label>
            <div className="added-element">
            {parameters.map((param, index) => (
              <div key={index}>
                {Object.keys(param)[0]}: {Object.values(param)[0]}
                <button onClick={() => handleDeleteParameter(index)}>Delete</button>
              </div>
            ))}
            </div>
            <input value={paramKey} onChange={(e) => setParamKey(e.target.value)} placeholder="Parameter Name" />
            <input value={paramValue} onChange={(e) => setParamValue(e.target.value)} placeholder="Value" />
            <button onClick={handleAddParameter}>Add Parameter</button>
            <button onClick={handleSuggestActivities}>Analyze Parameters</button>
            {activities.length > 0 && (<>
              <div className="analysis-output-box">
            {activities && activities.map((activity, index) => (
              <div key={index}>
                {activity}
              </div>
            ))}
            </div>
            </>)}
            
          </div>
        );
      case "symptoms":
        return (
          <div>
            <label>Symptoms:</label>
            <div className="added-element">
            {symptoms.map((symptom, index) => (
              <div key={index}>
                {symptom}
                <button onClick={() => handleDeleteSymptom(index)}>Delete</button>
              </div>
            ))}
            </div>
            <input value={symptomInput} onChange={(e) => setSymptomInput(e.target.value)} placeholder="Symptom" />
            <button onClick={handleAddSymptom}>Add Symptom</button>
            <button onClick={handleAnalyzeSymptoms}>Analyze Symptoms</button>
            {diseaseInput && (<>
              <div className="analysis-output-box">
            {diseaseInput && (<>{diseaseInput}</>)}
            </div>
            </>)}
           
          </div>
        );
      case "diagnosedDiseases":
        return (
          <div>
            <label>Diagnosed Diseases:</label>
            <div className="added-element">
            {diagnosedDiseases.map((disease, index) => (
              <div key={index}>
                {disease}
                <button onClick={() => handleDeleteDisease(index)}>Delete</button>
              </div>
            ))}
            </div>
            <input value={diseaseInput} onChange={(e) => setDiseaseInput(e.target.value)} placeholder="Disease" />
            <button onClick={handleAddDisease}>Add Disease</button>
          </div>
        );
      case "preconditions":
        return (
          <div>
            <label>Preconditions:</label>
            <div className="added-element">
            {preconditions.map((precondition, index) => (
              <div key={index}>
                {precondition}
                <button onClick={() => handleDeletePrecondition(index)}>Delete</button>
              </div>
            ))}
            </div>
            <input value={preconditionInput} onChange={(e) => setPreconditionInput(e.target.value)} placeholder="Precondition" />
            <button onClick={handleAddPrecondition}>Add Precondition</button>
          </div>
        );
      case "activities":
        return (
          <div>
            <label>Suggested Activities:</label>
            <div className="added-element">
            {activities.map((activity, index) => (
              <div key={index}>
                {activity}
                <button onClick={() => handleDeleteActivity(index)}>Delete</button>
              </div>
            ))}
            </div>
            <input value={activityInput} onChange={(e) => setActivityInput(e.target.value)} placeholder="Activity" />
            <button onClick={handleAddActivity}>Add Activity</button>
          </div>
        );
      case "medicines":
        return (
          <div>
            <label>Suggested Medicines:</label>
            <div className="added-element">
            {medicines.map((med, index) => (
              <div key={index}>
                {med.name} - {med.dosage} - {med.duration}
                <button onClick={() => handleDeleteMedicine(index)}>Delete</button>
              </div>
            ))}
            </div>
            <input placeholder="Name" value={medicine.name} onChange={(e) => setMedicine({ ...medicine, name: e.target.value })} />
            <input placeholder="Dosage" value={medicine.dosage} onChange={(e) => setMedicine({ ...medicine, dosage: e.target.value })} />
            <input placeholder="Duration" value={medicine.duration} onChange={(e) => setMedicine({ ...medicine, duration: e.target.value })} />
            <button onClick={handleAddMedicine}>Add Medicine</button>
          </div>
        );
      case "reports":
        return (
          <div>
            <label>Upload Report:</label>
            <div className="added-element">
            {reports.map((report, index) => (
              <div key={index}>
                <a
                  href={`http://localhost:5000/${report.url}`} // Use Flask backend route
                  target="_blank" // Open in a new tab
                  rel="noopener noreferrer" // Security best practice
                >
                  {report.type} - {report.file_type}
                </a>
                <button onClick={() => handleDeleteReport(index)}>Delete</button>
              </div>
            ))}
            </div>
            <select value={reportType} onChange={(e) => setReportType(e.target.value)}>
              <option value="">Select Report Type</option>
              <option value="Blood Report">Blood Report</option>
              <option value="X-Ray">X-Ray</option>
            </select>
            <select value={fileType} onChange={(e) => setFileType(e.target.value)}>
              <option value="">Select File Type</option>
              <option value="Image">Image</option>
              <option value="Pdf">PDF</option>
            </select>
            <input  type="file" onChange={(e) => setFile(e.target.files[0])} />
            <button onClick={handleAddReport}>Add Report</button>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="add-history-modal-overlay">
      <div className="add-history-modal-content">
        <button className="add-history-close-btn" onClick={onClose}>Close</button>
        <h2>Add Patient Visit History -
          {selectedHistory && (<>{selectedHistory.visit}</>)}
           {!selectedHistory && (<>{visitCount+1}</>)}
          </h2>
        <div className="add-history-patient-header">
          <h3>Patient: {patient.name}</h3>
          <p>Email: {patient.email}</p>
        </div>
        {notification && (
          <div className={`notification ${notification.isSuccess ? "success" : "error"}`}>
            {notification.message}
          </div>
        )}
        <div className="layout-container">
          <div className="sidebar">
            <ul>
              <li onClick={() => setActiveSection("purpose")}>Purpose</li>
              <li onClick={() => setActiveSection("parameters")}>Parameters</li>
              <li onClick={() => setActiveSection("symptoms")}>Symptoms</li>
              <li onClick={() => setActiveSection("diagnosedDiseases")}>Diagnosed Diseases</li>
              <li onClick={() => setActiveSection("preconditions")}>Preconditions</li>
              <li onClick={() => setActiveSection("activities")}>Activities</li>
              <li onClick={() => setActiveSection("medicines")}>Medicines</li>
              <li onClick={() => setActiveSection("reports")}>Reports</li>
            </ul>
          </div>
          <div className="main-content">
            {renderSection()}
            {/* <div>
              <label>Remarks:</label>
              <textarea value={remark} onChange={(e) => setRemark(e.target.value)} placeholder="Doctor's remarks" />
            </div> */}
            <button onClick={handleSaveChanges}>Save Changes</button>
            <button onClick={onClose}>Cancel</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddHistoryForm;