import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import '../static/css/DoctorDashboard.css';
import PatientSearchForm from './PatientSearchForm'; // Adjust path if needed

const DoctorDashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [doctor, setDoctor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Get email from location state
  const email = location.state?.email;
  console.log(email);

  // Fetch doctor details from backend
  useEffect(() => {
    if (!email) {
      setError('No email provided. Please log in again.');
      setLoading(false);
      return;
    }

    const fetchDoctorDetails = async () => {
      try {
        const response = await fetch(`http://localhost:5000/get-doctor?email=${email}`);
        if (!response.ok) {
          throw new Error('Failed to fetch doctor details');
        }

        const data = await response.json();
        setDoctor(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchDoctorDetails();
  }, [email]);

  const handleLogout = () => navigate('/');

  if (loading) {
    return <div className="DoctorDash_dashboard_container">Loading...</div>;
  }

  if (error) {
    return (
      <div className="DoctorDash_dashboard_container">
        <p className="error">{error}</p>
        <button onClick={handleLogout}>Log Out</button>
      </div>
    );
  }

  if (!doctor) {
    return (
      <div className="DoctorDash_dashboard_container">
        <p className="error">Doctor not found.</p>
        <button onClick={handleLogout}>Log Out</button>
      </div>
    );
  }


  return (
    <div className="DoctorDash_dashboard_container">
      {/* Doctor Info Block */}
      <div className="DoctorDash_dashboard_info-block">
        <header className="DoctorDash_dashboard_header">
          <div>
            <h1 className="DoctorDash_dashboard_welcome">
              Welcome, <span>{doctor.name}</span>
            </h1>
            <div className="DoctorDash_dashboard_qualifications">
              {doctor.education} • {doctor.specialization}
            </div>
          </div>
          <button onClick={handleLogout} className="DoctorDash_dashboard_logout-btn">
            <i className="fas fa-sign-out-alt"></i> Log Out
          </button>
        </header>
      </div>

      {/* Patient Search Section */}
      <div className="DoctorDash_dashboard_info-block">
        <PatientSearchForm  doctor_email={email}/>
      </div>

              </div>
  );
};

export default DoctorDashboard;