// frontend/src/DiabetesRAG.jsx (React Frontend)
import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import "../static/css/DiabetesRAG.css";
import DOMPurify from "dompurify";

export default function DiabetesRAG() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);

  const searchPapers = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch("http://localhost:4000/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      });
      const data = await response.json();
      setResults(data);
    } catch (error) {
      console.error("Search failed:", error);
    }
    setLoading(false);
  };

  return (
    <div className="diarag_app">
      <header className="diarag_header">
        <h1 className="diarag_title">🩺 Medical Research Assistant</h1>
        <form onSubmit={searchPapers} className="diarag_form">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Enter medical query..."
            disabled={loading}
            className="diarag_input"
          />
          <button type="submit" disabled={loading} className="diarag_button">
            {loading ? "🔍 Searching..." : "Search"}
          </button>
        </form>
      </header>

      {results && (
        <div className="diarag_results_container">
          <div
            className="diarag_summary"
            dangerouslySetInnerHTML={{
              __html: DOMPurify.sanitize(results.summary),
            }}
          />
        </div>
      )}
    </div>
  );
}
