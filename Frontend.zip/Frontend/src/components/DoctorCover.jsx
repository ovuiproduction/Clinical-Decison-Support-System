// import React, { useState, useEffect } from 'react';
// import { motion } from 'framer-motion';
// import { Link } from 'react-router-dom';
// import { FaUserMd, FaHeartbeat, FaHospital, FaStethoscope, FaPlus } from 'react-icons/fa';
// import '../static/css/DoctorCover.css';

// const DoctorCover = () => {
//   const [flipped, setFlipped] = useState(null);
//   const [currentTime, setCurrentTime] = useState(new Date());

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setCurrentTime(new Date());
//     }, 1000);
//     return () => clearInterval(timer);
//   }, []);

//   const formattedDate = currentTime.toLocaleDateString('en-US', {
//     weekday: 'long',
//     year: 'numeric',
//     month: 'long',
//     day: 'numeric'
//   });

//   const formattedTime = currentTime.toLocaleTimeString('en-US', {
//     hour: '2-digit',
//     minute: '2-digit',
//     second: '2-digit'
//   });

//   return (
//     <div className="coverpage_container">
//       <div className="coverpage_background">
//         {[...Array(10)].map((_, i) => (
//           <motion.div 
//             key={i}
//             className="coverpage_particle"
//             initial={{ scale: 0 }}
//             animate={{ 
//               scale: [0, 1, 0],
//               x: [0, (Math.random() - 0.5) * 200],
//               y: [0, (Math.random() - 0.5) * 200]
//             }}
//             transition={{
//               duration: 2 + Math.random() * 2,
//               repeat: Infinity,
//               repeatType: 'loop'
//             }}
//           />
//         ))}
//       </div>

//       <motion.div 
//         className="coverpage_content"
//         initial={{ opacity: 0 }}
//         animate={{ opacity: 1 }}
//         transition={{ duration: 0.8 }}
//       >
//         {/* Header Section */}
//         <div className="coverpage_header">
//           <div className="coverpage_time">
//             <div className="coverpage_date">{formattedDate}</div>
//             <div className="coverpage_clock">{formattedTime}</div>
//           </div>
          
//           <div className="coverpage_titlegroup">
//             <FaHeartbeat className="coverpage_pulse-logo" />
//             <h1 className="coverpage_title">
//               MedCare Pro <span>⚕</span>
//             </h1>
//             <p className="coverpage_subtitle">Advanced Medical Portal</p>
//           </div>
//         </div>

//         {/* Login Cards */}
//         <div className="coverpage_cardscontainer">
//           {/* Doctor Card */}
//           <motion.div 
//             className={`coverpage_card doctor ${flipped === 'doctor' ? 'flipped' : ''}`}
//             onMouseEnter={() => setFlipped('doctor')}
//             onMouseLeave={() => setFlipped(null)}
//             whileHover={{ scale: 1.05 }}
//           >
//             {/* Colored Square Decoration */}
//             <div className="coverpage_color-square coverpage_doctor-square"></div>

//             <div className="coverpage_cardfront">
//               <FaUserMd className="coverpage_cardicon pulse" />
//               <motion.h2 initial={{ y: 20 }} animate={{ y: 0 }}>
//                 Welcome Doctor
//               </motion.h2>
//               <p>Access to Portal</p>
//               <div className="coverpage_animated-border"></div>
//             </div>
//             <div className="coverpage_cardback">
//               <div className="coverpage_button-group">
//                 <Link to="/login/doctor">
//                   <motion.button 
//                     className="coverpage_loginbtn coverpage_doctorbtn"
//                     whileHover={{ scale: 1.1 }}
//                   >
//                     Login <FaStethoscope className="btn-icon" />
//                   </motion.button>
//                 </Link>
//               </div>
//               <p>Access patient records</p>
//             </div>
//           </motion.div>

//           {/* Admin Card */}
//           <motion.div 
//             className={`coverpage_card admin ${flipped === 'admin' ? 'flipped' : ''}`}
//             onMouseEnter={() => setFlipped('admin')}
//             onMouseLeave={() => setFlipped(null)}
//             whileHover={{ scale: 1.05 }}
//           >
//             {/* Colored Square Decoration */}
//             <div className="coverpage_color-square coverpage_admin-square"></div>

//             <div className="coverpage_cardfront">
//               <FaHospital className="coverpage_cardicon float" />
//               <motion.h2 initial={{ y: 20 }} animate={{ y: 0 }}>
//                 First Time Come
//               </motion.h2>
//               <Link to="/signup">
//                   <motion.button 
//                     className="coverpage_signupbtn coverpage_adminbtn"
//                     whileHover={{ scale: 1.1 }}
//                   >
//                     SignUp <FaHospital className="btn-icon" />
//                   </motion.button>
//                 </Link>
//               <p>SignUp for Portal</p>
//               <div className="coverpage_animated-border"></div>
//             </div>
//             <div className="coverpage_cardback">
//               <div className="coverpage_button-group">
//                 <Link to="/signup">
//                   <motion.button 
//                     className="coverpage_signupbtn coverpage_adminbtn"
//                     whileHover={{ scale: 1.1 }}
//                   >
//                     SignUp <FaHospital className="btn-icon" />
//                   </motion.button>
//                 </Link>
//               </div>
//               <p>Easy SignUp</p>
//             </div>
//           </motion.div>
//         </div>

//         {/* Footer Section */}
//         <div className="coverpage_footer">
//           <p className="coverpage_footertext">
//             Trusted by Medical Professionals Worldwide
//           </p>
//           <div className="coverpage_animatedicons">
//             <FaHeartbeat className="icon pulse" />
//             <FaStethoscope className="icon float" />
//             <FaPlus className="icon rotate" />
//           </div>
//         </div>
//       </motion.div>
//     </div>
//   );
// };

// export default DoctorCover;



import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { FaUserMd, FaHeartbeat, FaHospital, FaStethoscope, FaPlus } from 'react-icons/fa';
import '../static/css/DoctorCover.css';

const DoctorCover = () => {
  const [flipped, setFlipped] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formattedDate = currentTime.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const formattedTime = currentTime.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });

  return (
    <div className="coverpage_container">
      <div className="coverpage_background">
        {[...Array(10)].map((_, i) => (
          <motion.div 
            key={i}
            className="coverpage_particle"
            initial={{ scale: 0 }}
            animate={{ 
              scale: [0, 1, 0],
              x: [0, (Math.random() - 0.5) * 200],
              y: [0, (Math.random() - 0.5) * 200]
            }}
            transition={{
              duration: 2 + Math.random() * 2,
              repeat: Infinity,
              repeatType: 'loop'
            }}
          />
        ))}
      </div>

      <motion.div 
        className="coverpage_content"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        {/* Header Section */}
        <div className="coverpage_header">
          <div className="coverpage_time">
            <div className="coverpage_date">{formattedDate}</div>
            <div className="coverpage_clock">{formattedTime}</div>
          </div>
          
          <div className="coverpage_titlegroup">
            <FaHeartbeat className="coverpage_pulse-logo" />
            <h1 className="coverpage_title">
              MedSage <span>⚕</span>
            </h1>
            <p className="coverpage_subtitle">Advanced Medical Portal</p>
          </div>
        </div>

        {/* Login Cards */}
        <div className="coverpage_cardscontainer">
          {/* Doctor Card */}
          <motion.div 
            className={`coverpage_card doctor ${flipped === 'doctor' ? 'flipped' : ''}`}
            onMouseEnter={() => setFlipped('doctor')}
            onMouseLeave={() => setFlipped(null)}
            whileHover={{ scale: 1.05 }}
          >
            {/* Colored Square Decoration */}
            <div className="coverpage_color-square coverpage_doctor-square"></div>

            <div className="coverpage_cardfront">
              <FaUserMd className="coverpage_cardicon pulse" />
              <motion.h2 initial={{ y: 20 }} animate={{ y: 0 }}>
                Welcome Doctor
              </motion.h2>
              <p>Access to Portal</p>
              <div className="coverpage_animated-border"></div>
            </div>
            <div className="coverpage_cardback">
              <div className="coverpage_button-group">
                <Link to="/login/doctor">
                  <motion.button 
                    className="coverpage_loginbtn coverpage_doctorbtn"
                    whileHover={{ scale: 1.1 }}
                  >
                    Login <FaStethoscope className="btn-icon" />
                  </motion.button>
                </Link>
             
              </div>
              <p>Access patient records</p>
            </div>
          </motion.div>

          {/* Admin Card */}
          <motion.div 
            className={`coverpage_card admin ${flipped === 'admin' ? 'flipped' : ''}`}
            onMouseEnter={() => setFlipped('admin')}
            onMouseLeave={() => setFlipped(null)}
            whileHover={{ scale: 1.05 }}
          >
            {/* Colored Square Decoration */}
            <div className="coverpage_color-square coverpage_admin-square"></div>

            <div className="coverpage_cardfront">
              <FaHospital className="coverpage_cardicon float" />
              <motion.h2 initial={{ y: 20 }} animate={{ y: 0 }}>
                First Time Come
              </motion.h2>
              <p>SignUp for Portal</p>
              <div className="coverpage_animated-border"></div>
            </div>
            <div className="coverpage_cardback">
              <div className="coverpage_button-group">
                
                <Link to="/signup/doctor">
                  <motion.button 
                    className="coverpage_signupbtn coverpage_adminbtn"
                    whileHover={{ scale: 1.1 }}
                  >
                    SignUp <FaHospital className="btn-icon" />
                  </motion.button>
                </Link>
              </div>
              <p>Easy SignUp</p>
            </div>
          </motion.div>
        </div>

        {/* Footer Section */}
        <div className="coverpage_footer">
          <p className="coverpage_footertext">
            Trusted by Medical Professionals Worldwide
          </p>
          <div className="coverpage_animatedicons">
            <FaHeartbeat className="icon pulse" />
            <FaStethoscope className="icon float" />
            <FaPlus className="icon rotate" />
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default DoctorCover;
