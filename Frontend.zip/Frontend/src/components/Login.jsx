import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import '../css/login-doctor.css';

export default function Login() {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState(1); // Step 1: Enter Email, Step 2: Enter OTP
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch('http://localhost:5000/request-otp-doctor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Doctor not found');
      }

      setStep(2); // Move to OTP verification step
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleOtpSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch('http://localhost:5000/verify-otp-doctor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otp }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Invalid OTP');
      }

      // Redirect to doctor dashboard
      navigate('/doctor/dashboard', { state: { email: email } });

    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    console.log(email);
  }, [email]);

  return (
    <div className="login-doctor-container">
      <h2 className="login-doctor-title">Doctor Login</h2>
      {error && <p className="login-doctor-error">{error}</p>}

      {step === 1 && (
        <form onSubmit={handleEmailSubmit} className="login-doctor-form">
          <div className="login-doctor-form-group">
            <label htmlFor="email" className="login-doctor-label">Email</label>
            <input
              type="email"
              id="email"
              className="login-doctor-input"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="login-doctor-button" disabled={loading}>
            {loading ? 'Sending OTP...' : 'Next'}
          </button>
        </form>
      )}

      {step === 2 && (
        <form onSubmit={handleOtpSubmit} className="login-doctor-form">
          <div className="login-doctor-form-group">
            <label htmlFor="otp" className="login-doctor-label">Enter OTP</label>
            <input
              type="text"
              id="otp"
              className="login-doctor-input"
              placeholder="Enter OTP sent to your email"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="login-doctor-button" disabled={loading}>
            {loading ? 'Verifying...' : 'Verify & Login'}
          </button>
        </form>
      )}

      <p className="login-doctor-footer">
        Don't have an account? <Link to="/signup/doctor" className="login-doctor-link">Sign Up</Link>
      </p>
    </div>
  );
}