// import React, { useState, useEffect } from "react";
// import { useLocation } from "react-router-dom";
// import axios from "axios";
// import "../static/css/PatientProfile.css";
// import AddHistoryForm from "./AddHistoryForm";

// const PatientProfile = () => {
//   const location = useLocation();
//   const { patient: initialPatient } = location.state || {};

//   const [patient, setPatient] = useState(initialPatient);
//   const [error, setError] = useState(null);
//   const [isHistoryModalOpen, setHistoryModalOpen] = useState(false);
//   const [isAllergyModalOpen, setIsAllergyModalOpen] = useState(false);
//   const [selectedHistory, setSelectedHistory] = useState(null); // Track selected history for editing
//   const [newAllergy, setNewAllergy] = useState({
//     type: "",
//     name: "",
//     reaction: "",
//   });

//   // Fetch updated patient data from the backend
//   const fetchUpdatedPatient = async () => {
//     try {
//       const response = await axios.post(
//         "http://localhost:5000/patient",
//         {
//           email: patient.email,
//         },
//         {
//           headers: {
//             "Content-Type": "application/json",
//           },
//         }
//       );
//       setPatient(response.data);
//     } catch (err) {
//       setError(err.response?.data?.error || "❌ Patient not found.");
//     }
//   };

//   // Fetch updated patient data when the history modal is closed
//   useEffect(() => {
//     if (!isHistoryModalOpen) {
//       fetchUpdatedPatient();
//     }
//   }, [isHistoryModalOpen]);

//   if (!patient) {
//     return <p>❌ No patient data found. Please search again.</p>;
//   }

//   // Add new allergy to the list
//   const handleAddAllergy = (e) => {
//     e.preventDefault();
//     if (newAllergy.type && newAllergy.name && newAllergy.reaction) {
//       const updatedAllergies = [...patient.allergies, newAllergy];
//       updateAllergies(updatedAllergies);
//       setNewAllergy({ type: "", name: "", reaction: "" });
//     } else {
//       alert("⚠️ Please fill all fields!");
//     }
//   };

//   // Submit updated allergies to backend
//   const updateAllergies = async (updatedAllergies) => {
//     try {
//       await axios.post(`http://localhost:5000/update-allergies`, {
//         email: patient.email,
//         allergies: updatedAllergies,
//       });
//       alert("✅ Allergies updated successfully!");
//       fetchUpdatedPatient();
//       setIsAllergyModalOpen(false);
//     } catch (error) {
//       alert("❌ Failed to update allergies.");
//     }
//   };

//   // Close modal when clicking outside
//   const handleOverlayClick = (e) => {
//     if (e.target.classList.contains("ehr-overlay")) {
//       setIsAllergyModalOpen(false);
//       setHistoryModalOpen(false);
//     }
//   };

//   // Handle edit history
//   const handleEditHistory = (historyRecord) => {
//     setSelectedHistory(historyRecord); // Set the selected history record
//     setHistoryModalOpen(true); // Open the history modal
//   };

//   return (
//     <div className="ehr-profile-container">
//       {error&&(<p>{error}</p>)}
//       <h2 className="ehr-profile-title">👤 Patient Profile</h2>

//       <p>
//         <strong>Name:</strong> {patient.name}
//       </p>
//       <p>
//         <strong>Gender:</strong> {patient.gender}
//       </p>
//       <p>
//         <strong>Date of Birth:</strong> {patient.dob}
//       </p>
//       <p>
//         <strong>Blood Group:</strong> {patient.blood_group}
//       </p>
//       <p>
//         <strong>Phone:</strong> {patient.phone}
//       </p>
//       <p>
//         <strong>City:</strong> {patient.city}
//       </p>
//       <p>
//         <strong>State:</strong> {patient.state}
//       </p>

//       <h3>📋 Allergies:</h3>
//       {patient.allergies?.length > 0 ? (
//         patient.allergies.map((allergy, index) => (
//           <p key={index}>
//             {allergy.type} - {allergy.name} ({allergy.reaction})
//           </p>
//         ))
//       ) : (
//         <p>No allergies recorded.</p>
//       )}

//       <button
//         onClick={() => setIsAllergyModalOpen(true)}
//         className="ehr-add-allergy-btn"
//       >
//         ➕ Add Allergy
//       </button>

//       <h3>🩺 Medical History:</h3>
//       {patient.history?.length > 0 ? (
//         patient.history.map((record, index) => (
//           <div key={index} onClick={() => handleEditHistory(record)}>
//             <MedicalHistoryRecord record={record} />
//           </div>
//         ))
//       ) : (
//         <p>No medical history available.</p>
//       )}

//       <button onClick={() => setHistoryModalOpen(true)}>
//         ➕ Add Medical History
//       </button>

//       {isHistoryModalOpen && (
//         <AddHistoryForm
//           patient={patient}
//           visitCount={patient.history.length}
//           onClose={() => {
//             setHistoryModalOpen(false);
//             setSelectedHistory(null); // Reset selected history
//           }}
//           selectedHistory={selectedHistory} // Pass selected history for editing
//         />
//       )}

//       {isAllergyModalOpen && (
//         <div className="ehr-overlay" onClick={handleOverlayClick}>
//           <div className="ehr-modal">
//             <h3>Add New Allergy</h3>
//             <form onSubmit={handleAddAllergy}>
//               <label>
//                 Allergy Type:
//                 <input
//                   type="text"
//                   placeholder="e.g., Drug, Food"
//                   value={newAllergy.type}
//                   onChange={(e) =>
//                     setNewAllergy({ ...newAllergy, type: e.target.value })
//                   }
//                   required
//                   className="ehr-input"
//                 />
//               </label>

//               <label>
//                 Allergy Name:
//                 <input
//                   type="text"
//                   placeholder="e.g., Penicillin"
//                   value={newAllergy.name}
//                   onChange={(e) =>
//                     setNewAllergy({ ...newAllergy, name: e.target.value })
//                   }
//                   required
//                   className="ehr-input"
//                 />
//               </label>

//               <label>
//                 Reaction:
//                 <input
//                   type="text"
//                   placeholder="e.g., Rash, Anaphylaxis"
//                   value={newAllergy.reaction}
//                   onChange={(e) =>
//                     setNewAllergy({ ...newAllergy, reaction: e.target.value })
//                   }
//                   required
//                   className="ehr-input"
//                 />
//               </label>

//               <button type="submit" className="ehr-add-btn">
//                 Add
//               </button>
//             </form>

//             <button
//               onClick={() => setIsAllergyModalOpen(false)}
//               className="ehr-cancel-btn"
//             >
//               Cancel
//             </button>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// // Refactored Medical History Record Component
// const MedicalHistoryRecord = ({ record }) => (
//   <div className="history-card">
//     <div className="history-header">
//       <strong>Visit:</strong> {record.visit} - <em>{record.date}</em>
//     </div>
//     <p>
//       <strong>Purpose:</strong> {record.purpose}
//     </p>

//     {record.parameters && Object.keys(record.parameters).length > 0 && (
//       <div>
//         <strong>📊 Parameters:</strong>
//         <ul>
//           {Object.entries(record.parameters).map(([key, value]) => (
//             <li key={key}>
//               {key}: {value}
//             </li>
//           ))}
//         </ul>
//       </div>
//     )}

//     {Array.isArray(record.symptoms) && record.symptoms.length > 0 && (
//       <p>
//         <strong>🩹 Symptoms:</strong> {record.symptoms.join(", ")}
//       </p>
//     )}

//     {Array.isArray(record.preconditions) && record.preconditions.length > 0 && (
//       <div>
//         <strong>Preconditions :</strong>
//         <ul>
//           {record.preconditions.map((precondition, medIndex) => (
//             <li key={medIndex}>{precondition}</li>
//           ))}
//         </ul>
//       </div>
//     )}

//     {Array.isArray(record.diagnosed_diseases) &&
//       record.diagnosed_diseases.length > 0 && (
//         <p>
//           <strong>🔬 Diagnosed Diseases:</strong>{" "}
//           {record.diagnosed_diseases.join(", ")}
//         </p>
//       )}

//     {Array.isArray(record.suggested_medicines) &&
//       record.suggested_medicines.length > 0 && (
//         <div>
//           <strong>💊 Suggested Medicines:</strong>
//           <ul>
//             {record.suggested_medicines.map((med, medIndex) => (
//               <li key={medIndex}>
//                 {med.name} - {med.dosage} ({med.duration})
//               </li>
//             ))}
//           </ul>
//         </div>
//       )}

//     {Array.isArray(record.suggested_activities) &&
//       record.suggested_activities.length > 0 && (
//         <div>
//           <strong>Suggested Activities:</strong>
//           <ul>
//             {record.suggested_activities.map((activity, medIndex) => (
//               <li key={medIndex}>{activity}</li>
//             ))}
//           </ul>
//         </div>
//       )}

//     {Array.isArray(record.reports) && record.reports.length > 0 && (
//       <div>
//         <strong>Report</strong>
//         <ul>
//           {record.reports.map((report, ReportIndex) => (
//             <li key={ReportIndex}>
//               <a
//                 href={`http://localhost:5000/${report.url}`} // Use Flask backend route
//                 target="_blank" // Open in a new tab
//                 rel="noopener noreferrer" // Security best practice
//               >
//                 {report.type} - {report.file_type}
//               </a>
//             </li>
//           ))}
//         </ul>
//       </div>
//     )}

//     {record.remark && (
//       <p>
//         <strong>🗒️ Remark:</strong> {record.remark}
//       </p>
//     )}

//     {record.doctor_details && Object.keys(record.doctor_details).length > 0 && (
//       <div>
//         <strong>📊 Doctor Details:</strong>
//         <ul>
//           {Object.entries(record.doctor_details).map(([key, value]) => (
//             <li key={key}>
//               {key}: {value}
//             </li>
//           ))}
//         </ul>
//       </div>
//     )}
//   </div>
// );

// export default PatientProfile;


import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Link } from "react-router-dom";
import axios from "axios";
import "../static/css/PatientProfile.css";
import AddHistoryForm from "./AddHistoryForm";

import {
  FaStethoscope,
  FaHeartbeat,
  FaSearch,
  FaNotesMedical,
  FaMicroscope,
  FaXRay,
} from "react-icons/fa";


const PatientProfile = () => {
  const location = useLocation();
  const { patient: initialPatient } = location.state || {};

  const [patient, setPatient] = useState(initialPatient);
  const [error, setError] = useState(null);
  const [isHistoryModalOpen, setHistoryModalOpen] = useState(false);
  const [isAllergyModalOpen, setIsAllergyModalOpen] = useState(false);
  const [selectedHistory, setSelectedHistory] = useState(null);
  const [newAllergy, setNewAllergy] = useState({
    type: "",
    name: "",
    reaction: "",
  });
  const [activeSection, setActiveSection] = useState("details"); // Track active sidebar section

  // Fetch updated patient data from the backend
  const fetchUpdatedPatient = async () => {
    try {
      const response = await axios.post(
        "http://localhost:5000/patient",
        {
          email: patient.email,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      setPatient(response.data);
    } catch (err) {
      setError(err.response?.data?.error || "❌ Patient not found.");
    }
  };

  // Fetch updated patient data when the history modal is closed
  useEffect(() => {
    if (!isHistoryModalOpen) {
      fetchUpdatedPatient();
    }
  }, [isHistoryModalOpen]);

  if (!patient) {
    return <p>❌ No patient data found. Please search again.</p>;
  }

  // Add new allergy to the list
  const handleAddAllergy = (e) => {
    e.preventDefault();
    if (newAllergy.type && newAllergy.name && newAllergy.reaction) {
      const updatedAllergies = [...patient.allergies, newAllergy];
      updateAllergies(updatedAllergies);
      setNewAllergy({ type: "", name: "", reaction: "" });
    } else {
      alert("⚠️ Please fill all fields!");
    }
  };

  // Submit updated allergies to backend
  const updateAllergies = async (updatedAllergies) => {
    try {
      await axios.post(`http://localhost:5000/update-allergies`, {
        email: patient.email,
        allergies: updatedAllergies,
      });
      alert("✅ Allergies updated successfully!");
      fetchUpdatedPatient();
      setIsAllergyModalOpen(false);
    } catch (error) {
      alert("❌ Failed to update allergies.");
    }
  };

  // Close modal when clicking outside
  const handleOverlayClick = (e) => {
    if (e.target.classList.contains("ehr-overlay")) {
      setIsAllergyModalOpen(false);
      setHistoryModalOpen(false);
    }
  };

  // Handle edit history
  const handleEditHistory = (historyRecord) => {
    setSelectedHistory(historyRecord);
    setHistoryModalOpen(true);
  };

  return (
    <div>
    <h2 className="ehr-profile-header">👤 {patient.name}</h2>
    <div className="ehr-profile-container">
      {error && <p>{error}</p>}
     
      <div className="ehr-sidebar">
        <h3>Menu</h3>
        <ul>
          <li
            className={activeSection === "details" ? "active" : ""}
            onClick={() => setActiveSection("details")}
          >
            Patient Details
          </li>
          <li
            className={activeSection === "allergies" ? "active" : ""}
            onClick={() => setActiveSection("allergies")}
          >
            Allergies
          </li>
          <li
            className={activeSection === "history" ? "active" : ""}
            onClick={() => setActiveSection("history")}
          >
            Medical History
          </li>
        </ul>
      </div>

      <div className="ehr-content">
        {activeSection === "details" && (
          <div>
            <p>
              <strong>Name:</strong> {patient.name}
            </p>
            <p>
              <strong>Gender:</strong> {patient.gender}
            </p>
            <p>
              <strong>Date of Birth:</strong> {patient.dob}
            </p>
            <p>
              <strong>Blood Group:</strong> {patient.blood_group}
            </p>
            <p>
              <strong>Phone:</strong> {patient.phone}
            </p>
            <p>
              <strong>City:</strong> {patient.city}
            </p>
            <p>
              <strong>State:</strong> {patient.state}
            </p>
          </div>
        )}

        {activeSection === "allergies" && (
          <div>
            <h3>📋 Allergies:</h3>
            {patient.allergies?.length > 0 ? (
              patient.allergies.map((allergy, index) => (
                <p key={index}>
                  {allergy.type} - {allergy.name} ({allergy.reaction})
                </p>
              ))
            ) : (
              <p>No allergies recorded.</p>
            )}
            <button
              onClick={() => setIsAllergyModalOpen(true)}
              className="ehr-add-allergy-btn"
            >
              ➕ Add Allergy
            </button>
          </div>
        )}

        {activeSection === "history" && (
          <div>
            <h3>🩺 Medical History:</h3>
            {patient.history?.length > 0 ? (
              patient.history.map((record, index) => (
                <div key={index} onClick={() => handleEditHistory(record)}>
                  <MedicalHistoryRecord record={record} />
                </div>
              ))
            ) : (
              <p>No medical history available.</p>
            )}
            <button onClick={() => setHistoryModalOpen(true)}>
              ➕ Add Medical History
            </button>
          </div>
        )}
      </div>

      {isHistoryModalOpen && (
        <AddHistoryForm
          patient={patient}
          visitCount={patient.history.length}
          onClose={() => {
            setHistoryModalOpen(false);
            setSelectedHistory(null);
          }}
          selectedHistory={selectedHistory}
        />
      )}

      {isAllergyModalOpen && (
        <div className="ehr-overlay" onClick={handleOverlayClick}>
          <div className="ehr-modal">
            <h3>Add New Allergy</h3>
            <form onSubmit={handleAddAllergy}>
              <label>
                Allergy Type:
                <input
                  type="text"
                  placeholder="e.g., Drug, Food"
                  value={newAllergy.type}
                  onChange={(e) =>
                    setNewAllergy({ ...newAllergy, type: e.target.value })
                  }
                  required
                  className="ehr-input"
                />
              </label>

              <label>
                Allergy Name:
                <input
                  type="text"
                  placeholder="e.g., Penicillin"
                  value={newAllergy.name}
                  onChange={(e) =>
                    setNewAllergy({ ...newAllergy, name: e.target.value })
                  }
                  required
                  className="ehr-input"
                />
              </label>

              <label>
                Reaction:
                <input
                  type="text"
                  placeholder="e.g., Rash, Anaphylaxis"
                  value={newAllergy.reaction}
                  onChange={(e) =>
                    setNewAllergy({ ...newAllergy, reaction: e.target.value })
                  }
                  required
                  className="ehr-input"
                />
              </label>

              <button type="submit" className="ehr-add-btn">
                Add
              </button>
            </form>

            <button
              onClick={() => setIsAllergyModalOpen(false)}
              className="ehr-cancel-btn"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
    {/* Main Content Section */}
    <main className="cover-content">
        
        {/* Feature Blocks */}
        <div className="feature-blocks">
      
          <div className="feature-card">
            <FaMicroscope className="feature-icon" />
            <h2>Blood Analyzer</h2>
            <p>Unlock insights from blood reports with advanced diagnostics.</p>
            <Link to="/diagnosis-blood-report" className="feature-link">
              Explore Report
            </Link>
          </div>

          <div className="feature-card">
            <FaSearch className="feature-icon" />
            <h2>Research Insights</h2>
            <p>
              Access in-depth medical research and insights to enhance care.
            </p>
            <Link to="/research-insights" className="feature-link">
              Explore Insights
            </Link>
          </div>

          <div className="feature-card">
            <FaSearch className="feature-icon" />
            <h2>Diabetes Rag</h2>
            <p>
              Access in-depth medical research and insights to enhance care.
            </p>
            <Link to="/diabetes-rag" className="feature-link">
              Explore Insights
            </Link>
          </div>

          <div className="feature-card">
            <FaSearch className="feature-icon" />
            <h2>Risk Assesment</h2>
            <p>
             Analyze Risk
            </p>
            <Link to="/risk-assesment" className="feature-link">
              Explore Insights
            </Link>
          </div>


          <div className="feature-card">
            <FaXRay className="feature-icon" />
            <h2>X-Ray Analysis</h2>
            <p>
              Detect pneumonia with advanced X-ray image analysis for faster
              diagnosis.
            </p>
            <Link to="http://localhost:8000/" className="feature-link">
              Analyze X-Ray
            </Link>
          </div>


        </div>
      </main>
    </div>
  );
};

const MedicalHistoryRecord = ({ record }) => (
  <div className="history-card">
    <div className="history-header">
      <strong>Visit:</strong> {record.visit} - <em>{record.date}</em>
    </div>
    <p>
      <strong>Purpose:</strong> {record.purpose}
    </p>

    {record.parameters && Object.keys(record.parameters).length > 0 && (
      <div>
        <strong>📊 Parameters:</strong>
        <ul>
          {Object.entries(record.parameters).map(([key, value]) => (
            <li key={key}>
              {key}: {value}
            </li>
          ))}
        </ul>
      </div>
    )}

    {Array.isArray(record.symptoms) && record.symptoms.length > 0 && (
      <p>
        <strong>🩹 Symptoms:</strong> {record.symptoms.join(", ")}
      </p>
    )}

    {Array.isArray(record.preconditions) && record.preconditions.length > 0 && (
      <div>
        <strong>Preconditions :</strong>
        <ul>
          {record.preconditions.map((precondition, medIndex) => (
            <li key={medIndex}>{precondition}</li>
          ))}
        </ul>
      </div>
    )}

    {Array.isArray(record.diagnosed_diseases) &&
      record.diagnosed_diseases.length > 0 && (
        <p>
          <strong>🔬 Diagnosed Diseases:</strong>{" "}
          {record.diagnosed_diseases.join(", ")}
        </p>
      )}

    {Array.isArray(record.suggested_medicines) &&
      record.suggested_medicines.length > 0 && (
        <div>
          <strong>💊 Suggested Medicines:</strong>
          <ul>
            {record.suggested_medicines.map((med, medIndex) => (
              <li key={medIndex}>
                {med.name} - {med.dosage} ({med.duration})
              </li>
            ))}
          </ul>
        </div>
      )}

    {Array.isArray(record.suggested_activities) &&
      record.suggested_activities.length > 0 && (
        <div>
          <strong>Suggested Activities:</strong>
          <ul>
            {record.suggested_activities.map((activity, medIndex) => (
              <li key={medIndex}>{activity}</li>
            ))}
          </ul>
        </div>
      )}

    {Array.isArray(record.reports) && record.reports.length > 0 && (
      <div>
        <strong>Report</strong>
        <ul>
          {record.reports.map((report, ReportIndex) => (
            <li key={ReportIndex}>
              <a
                href={`http://localhost:5000/${report.url}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                {report.type} - {report.file_type}
              </a>
            </li>
          ))}
        </ul>
      </div>
    )}

    {record.remark && (
      <p>
        <strong>🗒️ Remark:</strong> {record.remark}
      </p>
    )}

    {record.doctor_details && Object.keys(record.doctor_details).length > 0 && (
      <div>
        <strong>📊 Doctor Details:</strong>
        <ul>
          {Object.entries(record.doctor_details).map(([key, value]) => (
            <li key={key}>
              {key}: {value}
            </li>
          ))}
        </ul>
      </div>
    )}
      
  </div>
);

export default PatientProfile;