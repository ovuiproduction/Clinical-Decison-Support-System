import React, { useState } from "react";
import axios from "axios"
import "../static/css/PatientRegistration.css";

const PatientRegistration = () => {
  const [formData, setFormData] = useState({
    name: "",
    dob: "",
    blood_group: "",
    phone: "",
    email: "",
    city: "",
    state: "",
    gender:""
  });
  const [error,setError] = useState("");
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    try {
      const response = await axios.post(
        "http://localhost:5000/register",
        formData,
        {
          headers: {
            "Content-Type": "application/json", // Explicitly specifying JSON format
          },
        }
      );
  
      if (response.status === 201) {
        setMessage("✅ Patient registered successfully!");
        setError("");
        setFormData({
          name: "",
          dob: "",
          blood_group: "",
          phone: "",
          email: "",
          city: "",
          state: "",
          gender:""
        });
      }
    } catch (err) {
      setError(err.response?.data?.error || "❌ Registration failed! Please try again.");
      setMessage("");
    }
  };

  return (
    <div className="ehr-registration-container">
      <h2 className="ehr-registration-title">Patient Registration</h2>
      {error && <p className="ehr-registration-message">{error}</p>}
      {message && <p className="ehr-registration-message">{message}</p>}
      <form className="ehr-registration-form" onSubmit={handleSubmit}>
        <div className="ehr-registration-form-group">
          <label>Name:</label>
          <input type="text" name="name" value={formData.name} onChange={handleChange} required />
        </div>

        <div className="ehr-registration-form-group">
          <label>Date of Birth:</label>
          <input type="date" name="dob" value={formData.dob} onChange={handleChange} required />
        </div>

        <div className="ehr-registration-form-group">
          <label>Gender :</label>
          <input type="text" name="gender" value={formData.gender} onChange={handleChange} required />
        </div>

        <div className="ehr-registration-form-group">
          <label>Blood Group:</label>
          <input type="text" name="blood_group" value={formData.blood_group} onChange={handleChange} required />
        </div>

        <div className="ehr-registration-form-group">
          <label>Phone:</label>
          <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required />
        </div>

        <div className="ehr-registration-form-group">
          <label>Email:</label>
          <input type="email" name="email" value={formData.email} onChange={handleChange} required />
        </div>

        <div className="ehr-registration-form-group">
          <label>City:</label>
          <input type="text" name="city" value={formData.city} onChange={handleChange} required />
        </div>

        <div className="ehr-registration-form-group">
          <label>State:</label>
          <input type="text" name="state" value={formData.state} onChange={handleChange} required />
        </div>

        <button type="submit" className="ehr-registration-submit">Register</button>
      </form>
    </div>
  );
};

export default PatientRegistration;