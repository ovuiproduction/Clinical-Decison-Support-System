import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "../static/css/PatientSearchForm.css";

import AIBot from "./AIBot"

const PatientSearchForm = () => {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate(); 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    const formData = new FormData();
    formData.append("email", email);

    try {
      const response = await axios.post("http://localhost:5000/patient", formData, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      navigate("/patient-profile", { state: { patient: response.data } });
    } catch (err) {
      setError(err.response?.data?.error || "❌ Patient not found.");
    }
  };

  return (
    <div className="root-ehr-container">
      <div className="ehr-header-main">CDSS - Clinical Decision Support System</div>
    <div className="ehr-search-container">
      <h2 className="ehr-search-title">🔍 Search Patient</h2>

      <form onSubmit={handleSubmit} className="ehr-search-form">
        <label htmlFor="email" className="ehr-search-label">Patient Email:</label>
        <input
          type="email"
          id="email"
          className="ehr-search-input"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter patient email"
          required
        />
        <button type="submit" className="ehr-search-button">Search</button>
      </form>
      {error && <p className="ehr-search-error">{error}</p>}

      <p className="patient-registration-link">
      <Link className="patient-registration-link-tag"  to="/patient-registration">Patient Registration</Link>
      </p>
    </div>

      <div className="ai-bot-main-display">
        <AIBot />
      </div>
   
    </div>
  );
};

export default PatientSearchForm;
