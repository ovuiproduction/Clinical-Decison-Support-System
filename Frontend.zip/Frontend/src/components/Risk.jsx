import React, { useState } from "react";
import axios from "axios";
import { Bar } from "react-chartjs-2";
import { Chart, registerables } from "chart.js";
import'../static/css/risk.css'
Chart.register(...registerables);

const RiskAssessment = () => {
  const [formData, setFormData] = useState({
    age: "",
    bp: "",
    cholesterol: "",
    glucose: "",
    weight: "",
    height: "",
    smoking: "no",
    familyHistory: "no",
    exercise: "0",
  });

  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const response = await axios.post(
        "http://localhost:4000/api/assess-risk",
        formData,
        {
            headers: {
              "Content-Type": "application/json",
            },
          }
      );

      if (!response.data?.risks) {
        throw new Error("Invalid response format");
      }

      setResults(response.data);
    } catch (error) {
      setError(error.response?.data?.message || error.message);
      setResults(null);
    } finally {
      setLoading(false);
    }
  };

  // Chart data and options
  const chartData = {
    labels: results ? Object.keys(results.risks) : [],
    datasets: [
      {
        label: "Risk Percentage",
        data: results ? Object.values(results.risks).map((r) => r.value) : [],
        backgroundColor: results
          ? Object.values(results.risks).map((r) => r.color)
          : ["#4CAF50", "#FFC107", "#F44336", "#2196F3", "#9C27B0"],
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        enabled: true,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        title: {
          display: true,
          text: "Risk Percentage",
        },
      },
      x: {
        title: {
          display: true,
          text: "Health Conditions",
        },
      },
    },
  };

  return (
    <div className="risk-assessment-container">
      <form onSubmit={handleSubmit}>
        <div className="form-grid">
          <div className="form-group">
            <label>Age (years)</label>
            <input
              type="number"
              required
              min="18"
              max="100"
              value={formData.age}
              onChange={(e) =>
                setFormData({ ...formData, age: e.target.value })
              }
            />
          </div>

          <div className="form-group">
            <label>Blood Pressure (mmHg)</label>
            <input
              type="number"
              required
              value={formData.bp}
              onChange={(e) =>
                setFormData({ ...formData, bp: e.target.value })
              }
            />
          </div>

          <div className="form-group">
            <label>Cholesterol (mg/dL)</label>
            <input
              type="number"
              required
              value={formData.cholesterol}
              onChange={(e) =>
                setFormData({ ...formData, cholesterol: e.target.value })
              }
            />
          </div>

          <div className="form-group">
            <label>Glucose (mg/dL)</label>
            <input
              type="number"
              required
              value={formData.glucose}
              onChange={(e) =>
                setFormData({ ...formData, glucose: e.target.value })
              }
            />
          </div>

          <div className="form-group">
            <label>Weight (kg)</label>
            <input
              type="number"
              required
              value={formData.weight}
              onChange={(e) =>
                setFormData({ ...formData, weight: e.target.value })
              }
            />
          </div>

          <div className="form-group">
            <label>Height (cm)</label>
            <input
              type="number"
              required
              value={formData.height}
              onChange={(e) =>
                setFormData({ ...formData, height: e.target.value })
              }
            />
          </div>

          <div className="form-group">
            <label>Smoking History</label>
            <select
              value={formData.smoking}
              onChange={(e) =>
                setFormData({ ...formData, smoking: e.target.value })
              }
            >
              <option value="no">Never</option>
              <option value="former">Former Smoker</option>
              <option value="current">Current Smoker</option>
            </select>
          </div>

          <div className="form-group">
            <label>Family History of Heart Disease</label>
            <select
              value={formData.familyHistory}
              onChange={(e) =>
                setFormData({ ...formData, familyHistory: e.target.value })
              }
            >
              <option value="no">No</option>
              <option value="yes">Yes</option>
            </select>
          </div>

          <div className="form-group">
            <label>Weekly Exercise (hours)</label>
            <input
              type="number"
              min="0"
              max="20"
              value={formData.exercise}
              onChange={(e) =>
                setFormData({ ...formData, exercise: e.target.value })
              }
            />
          </div>
        </div>

        <button type="submit" disabled={loading}>
          {loading ? "Analyzing..." : "Calculate Health Risks"}
        </button>
      </form>

      {error && <div className="error-message">Error: {error}</div>}

      {results && (
        <div className="results-section">
          <h3>Health Risk Analysis</h3>

          {Object.values(results.risks).every((r) => r.value === 0) ? (
            <div className="no-results">
              No significant risks detected based on input parameters
            </div>
          ) : (
            <>
              <div className="risk-meter-container">
                {Object.entries(results.visualization).map(([condition, data]) => (
                  <div key={condition} className="risk-item">
                    <div className="condition-label">{condition}</div>
                    <div className="risk-bar">
                      <div
                        className="risk-fill"
                        style={{
                          width: `${data.value}%`,
                          backgroundColor: data.color,
                        }}
                      ></div>
                    </div>
                    <div className="risk-percentage">{data.value}%</div>
                  </div>
                ))}
              </div>

             
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default RiskAssessment;