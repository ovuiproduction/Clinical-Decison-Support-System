import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "../css/signup-doctor.css"; // Ensure the correct CSS file is imported

export default function Signup() {
  const [name, setName] = useState("");
  const [education, setEducation] = useState("");
  const [specialization, setSpecialization] = useState("");
  const [email, setEmail] = useState("");
  const [hospitalName, setHospitalName] = useState("");
  const [hospitalAddress, setHospitalAddress] = useState("");
  const [contact, setContact] = useState("");
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const handleSignup = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const response = await fetch("http://localhost:5000/signup-doctor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          education,
          specialization,
          email,
          hospitalName,
          hospitalAddress,
          contact,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Doctor registration failed");
      }

      navigate("/login/doctor");
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="signup-doctor-container">
      <h2>Doctor Sign Up</h2>
      {error && <p className="signup-doctor-error">{error}</p>}
      <form onSubmit={handleSignup}>
        <div className="signup-doctor-form-group">
          <label htmlFor="name">Full Name</label>
          <input
            id="name"
            type="text"
            placeholder="Enter your full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div className="signup-doctor-form-group">
          <label htmlFor="education">Education</label>
          <input
            id="education"
            type="text"
            placeholder="e.g., MBBS, MD"
            value={education}
            onChange={(e) => setEducation(e.target.value)}
            required
          />
        </div>

        <div className="signup-doctor-form-group">
          <label htmlFor="specialization">Specialization</label>
          <input
            id="specialization"
            type="text"
            placeholder="e.g., Cardiologist, Pediatrician"
            value={specialization}
            onChange={(e) => setSpecialization(e.target.value)}
            required
          />
        </div>

        <div className="signup-doctor-form-group">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            placeholder="Enter your professional email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="signup-doctor-form-group">
          <label htmlFor="hospitalName">Hospital Name</label>
          <input
            id="hospitalName"
            type="text"
            placeholder="Enter hospital name"
            value={hospitalName}
            onChange={(e) => setHospitalName(e.target.value)}
            required
          />
        </div>

        <div className="signup-doctor-form-group">
          <label htmlFor="hospitalAddress">Hospital Address</label>
          <textarea
            id="hospitalAddress"
            placeholder="Enter full hospital address"
            value={hospitalAddress}
            onChange={(e) => setHospitalAddress(e.target.value)}
            required
          />
        </div>

        <div className="signup-doctor-form-group">
          <label htmlFor="contact">Contact Number</label>
          <input
            id="contact"
            type="tel"
            placeholder="Enter contact number"
            value={contact}
            onChange={(e) => setContact(e.target.value)}
            pattern="[0-9]{10}"
            required
          />
        </div>


        <button className="signup-doctor-button" type="submit">Register</button>
      </form>
      <p className="signup-doctor-link">
        Already have an account? <Link to="/login/doctor">Login here</Link>
      </p>
    </div>
  );
}